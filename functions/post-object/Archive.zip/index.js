const aws = require('aws-sdk');
const s3 = new aws.S3({ apiVersion: '2006-03-01' });
exports.handler = function(event, context, callback) {

  var imageType = event.body.substring(event.body..lastIndexOf(":")+1,event.body..lastIndexOf(";"));
  var buf = new Buffer(event.body.replace(/^data:image\/\w+;base64,/, ""),'base64')
  var data = {
    Bucket: 'crushexpress-test',
    Key: "testing.jpg",
    Body: buf,
    ContentEncoding: 'base64',
    ContentType: imageType
  };
  s3.putObject(data, function(err, data){
      if (err) {
        console.log(err);
        console.log('Error uploading data: ', data);
      } else {
        console.log('succesfully uploaded the image!');
      }
  });

  // API response
  var responseCode = 200;
  var responseBody = {
      "Test": "Testing"
  };
  console.log(responseBody);
  var response = {
      statusCode: responseCode,
      headers: {
        "Access-Control-Allow-Origin" : "*",
        "Test" : "123"
      },
      body: JSON.stringify(responseBody),
  };

  callback(null, response);
};
